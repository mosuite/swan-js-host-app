
/**
 * @file v8-globals.js
 * @desc mock v8 global variables
 */

global._naSwan = {};